/* For operating-system and compiler details...   */
/* Obtain details.c by changeing "Windows AMD64" */
/* to the appropriate string. */

char sysdetails_ASL[] = "Windows AMD64";
